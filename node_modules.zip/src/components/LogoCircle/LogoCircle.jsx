import "./LogoCircle.css";

export default function LogoCircle() {
  return <div className="logo-circle">RvaI</div>;
}
