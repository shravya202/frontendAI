import "./Navbar.css";

export default function Navbar({ onLogin }) {
  return (
    <header className="navbar">
      {/* LEFT LOGO */}
      <div className="nav-left">
        <div className="logo-circle">Rval</div>
        <span className="brand-name">Rval</span>
      </div>

      {/* CENTER NAV (ALL ITEMS) */}
      <nav className="nav-center">
        <a href="#">Home</a>
        <a href="#">Pricing</a>
        <button className="login-btn" onClick={onLogin}>
          Login
        </button>
      </nav>
    </header>
  );
}
