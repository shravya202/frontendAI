import { useState } from "react";
import "./AiIntake.css";

export default function AiIntake() {
  const [prompt, setPrompt] = useState("");
  const [status, setStatus] = useState("idle"); // idle | loading | confirm
  const [intent, setIntent] = useState(null);
  const [selectedExample, setSelectedExample] = useState(null);

  const handleGenerate = () => {
    if (prompt.trim().length < 10) {
      alert("Please describe your idea in 1–2 sentences.");
      return;
    }

    setStatus("loading");

    // 🔥 TEMP AI SIMULATION (frontend only)
    setTimeout(() => {
      if (selectedExample === "realestate") {
        setIntent({
          industry: "Real Estate",
          businessName: "Luxury Estates",
          services: [
            "Property Sales",
            "Luxury Villas",
            "Apartments",
            "Site Visits",
            "Legal Support",
            "Consultation",
          ],
          audience: "High-end buyers",
          style: "Luxury",
          contactPreference: "WhatsApp",
        });
      } else if (selectedExample === "coaching") {
        setIntent({
          industry: "Education",
          businessName: "Science Coaching Institute",
          services: [
            "Physics",
            "Chemistry",
            "Mathematics",
            "Exam Preparation",
          ],
          audience: "10th–12th Students",
          style: "Minimal",
          contactPreference: "Contact Form",
        });
      } else {
        // Default / Hospital / Free text
        setIntent({
          industry: "Hospital",
          businessName: "Lifeline",
          services: ["Cardiology", "Physiotherapy"],
          audience: "Families",
          style: "Modern",
          contactPreference: "Appointments",
        });
      }

      setStatus("confirm");
    }, 1500);
  };

  return (
    <div className="ai-intake-page">
      <div className="ai-intake-box">

        {/* ================= IDLE STATE ================= */}
        {status === "idle" && (
          <>
            <h1>Describe what you want to build</h1>
            <p>
              RvaI understands your idea and generates a complete website UI.
            </p>

            <textarea
              className="ai-input"
              placeholder="Website for a hospital named Lifeline with cardiology, physiotherapy, families as target, modern style."
              value={prompt}
              onChange={(e) => {
                setPrompt(e.target.value);
                setSelectedExample(null); // free text overrides example
              }}
            />

            <div className="examples">
              <span
                onClick={() => {
                  setPrompt(
                    "A real estate website in Hyderabad, luxury tone, 6 services, WhatsApp contact CTA."
                  );
                  setSelectedExample("realestate");
                }}
              >
                Real estate (luxury)
              </span>

              <span
                onClick={() => {
                  setPrompt(
                    "Coaching institute for science courses, 10th–12th students, minimal theme."
                  );
                  setSelectedExample("coaching");
                }}
              >
                Coaching institute
              </span>

              <span
                onClick={() => {
                  setPrompt(
                    "Hospital website named Lifeline with cardiology and physiotherapy."
                  );
                  setSelectedExample("hospital");
                }}
              >
                Hospital website
              </span>
            </div>

            <button
              className="generate-btn"
              disabled={prompt.trim().length < 10}
              onClick={handleGenerate}
            >
              Generate UI
            </button>
          </>
        )}

        {/* ================= LOADING STATE ================= */}
        {status === "loading" && (
          <>
            <h2>Analyzing your idea…</h2>
            <div className="loader"></div>
            <p className="loading-text">
              RvaI is understanding your requirements
            </p>
          </>
        )}

        {/* ================= CONFIRM STATE ================= */}
        {status === "confirm" && intent && (
          <>
            <h2>Here’s what I understood</h2>

            <div className="intent-card">
              <p><strong>Industry:</strong> {intent.industry}</p>
              <p><strong>Business Name:</strong> {intent.businessName}</p>
              <p><strong>Services:</strong> {intent.services.join(", ")}</p>
              <p><strong>Audience:</strong> {intent.audience}</p>
              <p><strong>Style:</strong> {intent.style}</p>
              <p><strong>Contact:</strong> {intent.contactPreference}</p>
            </div>

            <div className="confirm-actions">
              <button className="primary-btn">
                Looks good, continue
              </button>

              <button
                className="secondary-btn"
                onClick={() => {
                  setStatus("idle");
                  setIntent(null);
                }}
              >
                Edit description
              </button>
            </div>
          </>
        )}

      </div>
    </div>
  );
}
